$(document).ready(function(){
    $('#tipoUsu').DataTable();
});

$(document).ready(function(){
    $('#usuario').DataTable();
});

